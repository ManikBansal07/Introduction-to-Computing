a = int(input('Enter the value of a:'))
b = int(input('Enter the value of b:'))
c = int(input('Enter the value of c:'))

d = int((a+b+c)/3)

print('The average of the given numbers = ', d)