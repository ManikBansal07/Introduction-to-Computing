a = float(input('Please enter your gross income to the nearest penny '))
b = int(input('Please enter the number of dependents '))

taxable_income = float(a-10000-(3000*b))

tax = float(taxable_income*0.2)
print('Total Payable Tax = ', tax)