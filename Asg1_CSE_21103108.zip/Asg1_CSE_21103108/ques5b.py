list = ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']

# Ques 5 part b

list[3:5] = ['purple']

print(list)

