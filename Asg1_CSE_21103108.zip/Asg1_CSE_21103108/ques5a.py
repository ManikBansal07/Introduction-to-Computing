list = ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']

# Ques 5 part a

del list[3]

print(list)

