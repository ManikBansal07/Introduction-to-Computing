sid = input('Please enter your Student ID: ')
name = input('Please enter your name: ')
gender = input('Gender : M/F/U ')
branch = input('Please enter your branch name: ')
cgpa = input('Please enter your cgpa ')

L = [sid, name, gender, branch, cgpa]

print(L)