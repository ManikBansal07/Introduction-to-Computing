std1 = int(input('Student 1: '))
std2 = int(input('Student 2: '))
std3 = int(input('Student 3: '))
std4 = int(input('Student 4: '))
std5 = int(input('Student 5: '))

L = [std1, std2, std3, std4, std5]

print('List of marks of the students: ',L)

L.sort()

print('List of marks of the students in the ascending order: ',L)

L.sort(reverse = True)

print('List of marks of the students in the descenind order: ',L)